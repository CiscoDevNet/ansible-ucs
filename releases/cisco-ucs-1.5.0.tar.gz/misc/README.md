# Miscellaneous Items

This folder contains miscellaneous items related to the collection. Trainings, DevNet Workshop giudes, etc.